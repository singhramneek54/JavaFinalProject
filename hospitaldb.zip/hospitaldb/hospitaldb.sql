create database hospitaldb;

use hospitaldb;

create table admin(
username	varchar(15) not null,
password	varchar(15) not null);

insert into admin values('Satya',	'Satya'),
('admin',	'admin'),
('Jatin',	'Jatin'),
('Rajesh',	'Rajesh');

create table appointment(
dName	varchar(20) not null,
pName	varchar(15) not null,
room	int(11) not null);

insert into appointment values('Rajesh', 'Satya', '100'),
('Satya', 'Rajesh', '101'),
('Jatin', 'Ramneek', '102'),
('Ramneek', 'Jatin', '103');


create table doctor(
count	int(11)	not null,
date	varchar(10)	not null,
id	varchar(10)	not null,
name	varchar(30)	not null,
age	int(5)	not null,
gender	varchar(8)	not null,
blood	varchar(4)	not null,
dept	varchar(20)	not null,
phone	varchar(15)	not null,
email	varchar(30)	not null,
status	varchar(10)	not null,
address	varchar(20)	not null,
room	int(11)	not null,
username	varchar(20)	not null,
password	varchar(30)	not null);


insert into doctor values
('1', '05-04-2018', 'd101', 'Rajesh', '24', 'Male', 'A-', 'Medecine', '+6476734958', 'rajesh@gmail.com', 'Single', 'North York', '100', 'Rajesh', 'Rajesh'),
('2', '30-01-2018', 'd102', 'Jatin', '24', 'Male', 'A+', 'Dental', '+6476734959', 'jatin@gmail.com', 'Married', 'Toronto', '102', 'Jatin', 'Jatin'),
('3', '13-12-2016', 'd103', 'Satya', '35', 'Male', 'AB-', 'Neurology', '+6476734957', 'satya@gmail.com', 'Divorced', 'Mississauga', '101', 'Satya', 'Satya'),
('4', '20-0802015', 'd104', 'Ramneek', '36', 'Male', 'B+', 'Nutrition', '+6476734956', 'ramneek@gmail.com', 'Single', 'Scarborough', '103', 'Ramneek', 'Ramneek'),
('5', '10-08-2017', 'd105', 'Manish', '25', 'Male', 'O-', 'Gynaecology', '+6476734955', 'manish@gmail.com', 'Single', 'North York', '104', 'Manish', 'Manish'),
('6', '15-03-2016', 'd106', 'Manoj', '26', 'Male', 'B-', 'Cardiology', '+6476734954', 'manoj@gmail.com', 'Married', 'Toronto', '105', 'Manoj', 'Manoj'),
('7', '25-03-2015', 'd107', 'Karan', '28', 'Male', 'O+', 'Haematology', '+6476734953', 'karan@gmail.com', 'Married', 'Scarborough', '106', 'Karan', 'Karan'),
('8', '20-12-2013', 'd108', 'Mani', '30', 'Male', 'B-', 'Microbiology', '+6476734952', 'mani@gmail.com', 'Married', 'Mississauga', '107', 'Mani', 'Mani'),
('9', '28-09-2009', 'd109', 'Pavan', '29', 'Male', 'O+', 'Gynaecology', '+6476734951', 'pavan@gmail.com', 'Single', 'Toronto', '108', 'Pavan', 'Pavan'),
('10', '13-23-2015', 'd110', 'Simha', '24', 'Male', 'O+', 'Microbiology', '+6476734950', 'simha@gmail.com', 'Single', 'North York', '109', 'Simha', 'Simha');


create table patient(
count	int(11)	not null,
date	varchar(10)	not null,
id	varchar(20)	not null,
name	varchar(20)	not null,
age	int(5)	not null,
gender	varchar(10)	not null,
address	varchar(20)	not null,
phone	varchar(20)	not null,
status	varchar(10)	not null,
disease	varchar(20)	not null,
room	int(11)	not null);

insert into patient values
('1', '10-03-2018', 'p101', 'Rajesh', '20', 'Male', 'Toronto', '+6476734912', 'Single', 'Feaver', '100'),
('2', '11-06-2018', 'p102', 'Jatin', '21', 'Male', 'Mississauga', '+6476734913', 'Single', 'Dengue', '102'),
('3', '12-05-2017', 'p103', 'Satya', '25', 'Male', 'Scarborough', '+6476734914', 'Married', 'Jondish', '101'),
('4', '13-03-2016', 'p104', 'Ramneek', '24', 'Male', 'Toronto', '+6476734915', 'Divorced', 'Malaria', '103'),
('5', '14-12-2017', 'p106', 'Manish', '27', 'Male', 'North York', '+6476734916', 'Married', 'Tyfoyed', '104'),
('6', '15-12-2017', 'p107', 'Manoj', '22', 'Male', 'Scarborough', '+6476734917', 'Single', 'Feaver', '105');


create table receptionist(
count	int(11)	not null,
joining	varchar(15)	not null,
id	varchar(15)	not null,
name	varchar(30)	not null,
age	int(5)	not null,
gender	varchar(10)	not null,
blood	varchar(4)	not null,
email	varchar(40)	not null,
phone	varchar(17)	not null,
address	varchar(30)	not null,
status	varchar(10)	not null,
username	varchar(20)	not null,
password	varchar(30)	not null);

insert into receptionist values
('1', '21-04-2013', 'R101', 'Manoj', '21', 'Male', 'O+', 'manoj@gmail.com', '+6476734924', 'Toronto', 'Single', 'Manoj', 'Manoj12'),
('2', '22-06-2018', 'R102', 'Rajesh', '24', 'Male', 'A-', 'rajesh@gmail.com', '+6476734925', 'Mississauga', 'Married', 'Rajesh', 'Rajesh12'),
('3', '13-06-2018', 'R103', 'Jatin', '24', 'Male', 'AB-', 'jatin@gmail.com', '+6476734926', 'Scarborough', 'Single', 'Jatin', 'Jatin12'),
('4', '14-12-2018', 'R104', 'Bharath', '25', 'Male', 'O+', 'bharath@gmail.com', '+6476734927', 'North York', 'Married', 'Bharath', 'Bharath12'),
('5', '15-12-2018', 'R105', 'Satya', '23', 'Male', 'AB-', 'satya@gmail.com', '+6476734928', 'Mississauga', 'Single', 'Satya', 'Satya12');
